import { Copafilmes } from './copafilmes.model';

describe('Copafilmes', () => {
  it('should create an instance', () => {
    expect(new Copafilmes()).toBeTruthy();
  });
});
