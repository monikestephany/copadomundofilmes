export class Copafilmes {
    Id:string;
    Titulo:string;
    Ano:number;
    Nota:number;
}
